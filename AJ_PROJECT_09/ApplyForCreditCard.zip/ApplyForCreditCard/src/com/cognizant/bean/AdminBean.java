package com.cognizant.bean;

public class AdminBean {
	private String idS;
	private String pasS;
	public String getIdS() {
		return idS;
	}
	public void setIdS(String idS) {
		this.idS = idS;
	}
	public String getPasS() {
		return pasS;
	}
	public void setPasS(String pasS) {
		this.pasS = pasS;
	}

}

package com.cognizant.bean;

import java.math.BigInteger;

public class UserBeantemp {  
private String FirstName;
private String LastName;
private int Age;
private String gender;
private long ContactNumber;
private BigInteger UID;
private String Password;

private String email ;




@Override
public String toString() {
	return "User [FirstName=" + FirstName + ", LastName=" + LastName + ", Age=" + Age + ", gender=" + gender
			+ ", ContactNumber=" + ContactNumber + ", UID=" + UID + ", Password=" + Password + ", email=" + email + "]";
}

public UserBeantemp(String firstName, String lastName, int age, String gender, long contactNumber, BigInteger uID,
		String password, String email) {
	super();
	FirstName = firstName;
	LastName = lastName;
	Age = age;
	this.gender = gender;
	ContactNumber = contactNumber;
	UID = uID;
	Password = password;
	this.email = email;
}

public String getFirstName() {
	return FirstName;
}

public void setFirstName(String firstName) {
	FirstName = firstName;
}

public String getLastName() {
	return LastName;
}

public void setLastName(String lastName) {
	LastName = lastName;
}

public int getAge() {
	return Age;
}

public void setAge(int age) {
	Age = age;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public long getContactNumber() {
	return ContactNumber;
}

public void setContactNumber(long contactNumber) {
	ContactNumber = contactNumber;
}

public BigInteger getUID() {
	return UID;
}

public void setUID(BigInteger uID) {
	UID = uID;
}

public String getPassword() {
	return Password;
}

public void setPassword(String password) {
	Password = password;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public UserBeantemp() {
	super();
	// TODO Auto-generated constructor stub
}




}
package com.cognizant.bean;

import java.math.BigInteger;

public class UserBean {
	
	
	private String password ;
	private BigInteger UID ;
	  private String firstName;
      private String lastName;
      public boolean valid;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public BigInteger getUID() {
		return UID;
	}
	public void setUID(BigInteger uID) {
		UID = uID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	
	
	
	
}
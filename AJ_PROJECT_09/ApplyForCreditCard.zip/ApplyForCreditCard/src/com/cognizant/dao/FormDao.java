package com.cognizant.dao;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cognizant.bean.FormBean;

import utilities.ConnectionProvider;

public class FormDao {
	
	public static boolean detailsvalidate(FormBean obj) {
		
		boolean status = false ;
		
		try {
			
			Connection con = ConnectionProvider.getCon();
			
			// SQL QUERY TO GET THE VALUES FROM TABLE 
			PreparedStatement ps  = con.prepareStatement(
					"select * from applied_users where FIRSTNAME = ?  and LASTNAME = ?   and AGE = ? and GENDER = ? and CONTACTNUMBER = ?   and UIDNUMBER= ? and PASSWORD = ? ");
					
			ps.setString(1, obj.getFirstName());
			ps.setString(2, obj.getLastName());
			ps.setInt(3, obj.getAge());
			ps.setString(4, obj.getGender());
			ps.setLong(5, obj.getContactNumber());
			ps.setBigDecimal(6, new BigDecimal(obj.getUID()));
			ps.setString(7, obj.getPassword());
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			//123456789
			//3fdsdfsdfd
			
		}catch(Exception e ) {
			
			
		}
	

		return status; 	
		}
	
		
	}
	



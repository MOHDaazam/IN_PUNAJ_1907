package com.cognizant.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cognizant.bean.FormBean;

import utilities.ConnectionProvider;

public class AlreadyAppliedDao {

	public static boolean AlreadyVerifed(FormBean obj){
		
		boolean status  = false  ;
		
		
		try {
			Connection con = ConnectionProvider.getCon();
			
			PreparedStatement ps = con.prepareStatement(
					
					"select * from applied_users where UIDNUMBER = ? and VERIFIED = ? ");

			
			ps.setBigDecimal(1, new BigDecimal(obj.getUID()));
			ps.setString(2, "TRUE");
			
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
			
			
		}catch (Exception e){
			
			System.out.println("Exception from alreadyVerified : "+ e );
			
		}
		
		return status  ;
		
	}
	
	
}

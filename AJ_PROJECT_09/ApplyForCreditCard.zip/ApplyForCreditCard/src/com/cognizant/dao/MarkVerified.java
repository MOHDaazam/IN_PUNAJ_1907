package com.cognizant.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cognizant.bean.FormBean;
import utilities.ConnectionProvider;

public class MarkVerified {
	public static boolean markVerified(FormBean obj)
	 {
	 boolean status = false ;
		try {
			
			Connection con=ConnectionProvider.getCon();
			PreparedStatement ps=con.prepareStatement(
			"update applied_users set Verified = ? where UIDnumber= ?" );
		    //ps.setLong(1, obj.getContactNumber());
		    
		    ps.setString (1 , "TRUE");
		    ps.setBigDecimal(2, new BigDecimal(obj.getUID()));
		   
		   status = ps.execute();  
		    
		     
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
		 }
		return status ;
	 }
}
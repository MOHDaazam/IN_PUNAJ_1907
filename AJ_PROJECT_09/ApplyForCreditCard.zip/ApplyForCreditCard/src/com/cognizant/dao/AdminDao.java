package com.cognizant.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
 
import java.sql.SQLException;

import com.cognizant.bean.AdminBean;



import utilities.ConnectionProvider;

public class AdminDao {
	public static boolean adminDetails(AdminBean obj)
	 {
	 boolean status = false ;
		try {
			
			Connection con=ConnectionProvider.getCon();
			PreparedStatement ps=con.prepareStatement(
					"Select * from adminaccess where ADMINID = ? and ADMINPASS = ?" );
		    
		    ps.setString(1,obj.getIdS());
		    ps.setString(2,obj.getPasS());
		    
		    ResultSet rs = ps.executeQuery();
		    
		     status = rs.next() ;
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
		 }
		return status ;
	 }
}
	
		
	

package com.cognizant.dao;

import java.math.BigDecimal;


import java.sql.*;

import com.cognizant.bean.UserBean;

import utilities.ConnectionProvider;


public class UserDao {

	public static boolean validateUser(UserBean obj) {
		
		boolean status = false ;
		
		
		try {
			
			Connection con = ConnectionProvider.getCon();
			
			
			// SQL QUERY TO GET THE VALUES FROM TABLE 
			PreparedStatement ps  = con.prepareStatement(
					"select * from applied_users where UIDNUMBER= ? and PASSWORD = ? ");
					
			ps.setBigDecimal(1, new BigDecimal(obj.getUID()));
			ps.setString(2, obj.getPassword());
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			//123456789
			//3fdsdfsdfd
			
		}catch(Exception e ) {}
	
	return status; 
}
}

package com.cognizant.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.bean.UserBean;

import utilities.ConnectionProvider;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	 	String password = request.getParameter("Password");
        String UIDTemp = request.getParameter("UID");
      
        BigInteger bg = new BigInteger(UIDTemp);
    	UserBean obj = new UserBean(); 
        
         obj.setUID(bg);
         
         obj.setPassword(password);
         
        
         boolean STATUS = com.cognizant.dao.UserDao.validateUser(obj);

         if(STATUS == true){  
         	
          
         try {
         	
         	Connection con=ConnectionProvider.getCon();
         	PreparedStatement ps=con.prepareStatement(
         	"Select * from applied_users where UIDNUMBER = ?" );
             
             ps.setBigDecimal(1, new BigDecimal(obj.getUID()));
             
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()){
             	String FirstName = rs.getString(1); 
             	String LastName = rs.getString(2);
     
             	
                //out.println("Please wait connecting your dashboard ...... ");
                obj.setFirstName(FirstName);
                obj.setLastName(LastName);
               // out.println(obj.getFirstName() + obj.getLastName());
               
             
        		//request.getSession(true);      
                String UIDNUMBER = obj.getUID().toString();
                
                HttpSession session = request.getSession(true);
                session.setAttribute("UIDNUMBER", UIDNUMBER);
                session.setAttribute("FIRSTNAME",FirstName);
                session.setAttribute("USER-PROFILE" ,obj);
                //System.out.println("if chla");
                response.sendRedirect("views/UserDashboard/UserProfile.jsp");
                
                
             /*   session.setAttribute("UIDNUMBER", UIDNUMBER);
        		session.setAttribute("FIRSTNAME",FirstName); 
                session.setAttribute("USER-PROFILE" ,obj);
                
                
               // response.sendRedirect("userProfile.jsp");
                response.setHeader("Refresh", "3;url=UserDashboard/UserProfile.jsp");
                */
            
            }
         } catch (Exception e) {
     		System.out.println("Exception From UserServlet  " + e);
     		
     	}} else {
           // 	System.out.println("else chla");
            	 response.sendRedirect("views/userLoginError.jsp");
                 response.setHeader("Refresh", "3;url=views/UserLogin.jsp");

            }
	}
}
        
		
	




package com.cognizant.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.bean.AdminBean;
import com.cognizant.bean.FormBean;
import com.cognizant.dao.AlreadyAppliedDao;
import com.cognizant.dao.FormDao;
import com.cognizant.dao.MarkVerified;

import utilities.CalculateAge;
import utilities.ConnectionProvider;
import utilities.SqlDate;




/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/FormServlet")
public class FormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	   	String FirstName = request.getParameter("FirstName").toLowerCase().trim();
        String LastName = request.getParameter("LastName").toLowerCase().trim();
        
       // THIS PART OF CODE CONVERT DATE OF BIRTH TO AGE ///
        
        String DOB = request.getParameter("DOB"); 


       LocalDate birthDate = LocalDate.parse(DOB);
       LocalDate currentDate = LocalDate.now();
        
        int age  = CalculateAge.calculateage(birthDate, currentDate);
       
          ///////////////////////////////////////////////////////////  
        
        //AGAIN FORM PARAMETERS//
		
        String Gender = request.getParameter("Gender");
        
        String CN =request.getParameter("ContactNumber");
        long ContactNumber = Long.parseLong(CN); 
        
        String Password = request.getParameter("Password");
      
        String UIDTemp = request.getParameter("UID");
        BigInteger bg = new BigInteger(UIDTemp);
        
       // int status = Integer.parseInt(request.getParameter(""));
        String Email = request.getParameter ("Email").trim();
		
        ///////////////////////////////////////////////////////////  
        
        
        
        ////////////GENERATING UNIQUE & RANDOM APPLICATION ID /////////////////
        
        
            UUID uuidRandom = UUID.randomUUID(); 
     		Long AppID1 = uuidRandom.getMostSignificantBits();
     		String AppID2 = String.valueOf(AppID1).replace("-", "");
      		Long ApplicationID = Long.parseLong(AppID2);
        
        
       ///////////////////////////////////////////////////////////////////////////////
		
       //SENDING VALUES OF FORM PARAMETERS TO FORM-BEAN/////
      		
      		FormBean obj = new FormBean(); 
            obj.setFirstName(FirstName);
            obj.setLastName(LastName);
            obj.setContactNumber(ContactNumber);
            obj.setAge(age);
            obj.setGender(Gender);
            obj.setUID(bg);
            obj.setPassword(Password);
            obj.setEmail(Email);
            String name2 = obj.getFirstName();
            
         ///////////////////////////////////////////////////////////////////////////////  
		
		//PASSING FORM-BEAN OBJECT TO CHECK IF ALREADY APPLIED OR NOT///
      
            boolean alreadyValidate = AlreadyAppliedDao.AlreadyVerifed(obj);
            if(alreadyValidate){
            	 HttpSession session = request.getSession(true);
                 session.setAttribute("FIRSTNAME", obj.getFirstName());
            	
        	 	response.sendRedirect("views/alreadyApplied.jsp");
		
	}else {
		

		
			boolean STATUS = FormDao.detailsvalidate(obj);  
			
		
			

	
			if(STATUS){  
				
		
				
			MarkVerified.markVerified(obj);
			
		
			
			 HttpSession session = request.getSession(true);
            session.setAttribute("FIRSTNAME", obj.getFirstName());
			
			 response.sendRedirect("views/applicationSubmitted.jsp");
			 
			 
			 
			 
			 
			 
			 
		
	////////THIS PART OF CODE WILL INSERT FORM DETAILS IN ADMIN //////////////////////////////	
		try {
			
		Connection con1=ConnectionProvider.getCon();
		PreparedStatement ps1=con1.prepareStatement(
	    "INSERT INTO ADMIN (UIDNUMBER, APPLICATIONID, APPLICATIONDATE, STATUS , CARDNAME ) VALUES (?,?,?,?,?) " );
		   
		    
		  ps1.setBigDecimal(1, new BigDecimal(obj.getUID()));
	      ps1.setLong (2 , ApplicationID);
		  ps1.setDate(3, SqlDate.getCurrentDate());
		  ps1.setString(4, "Under Process");
		  ps1.setString(5, FirstName );
		    
	      ps1.executeUpdate();  
		    
    ///////////////////////////////////////////////////////////////////////////////////////		    
		    
		     

			
		   
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}

		}


				

	}

	
	}
}



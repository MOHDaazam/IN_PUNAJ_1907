package utilities;

public class SqlDate {
	
	public static java.sql.Date getCurrentDate() {
	    java.util.Date today = new java.util.Date();
	    return new java.sql.Date(today.getTime());
	}
	
	public static void main (String args []) {
		
		System.out.println(getCurrentDate());
	}
	
	
}

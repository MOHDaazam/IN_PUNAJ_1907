package utilities;
import java.time.LocalDate;
import java.time.Period;

public class CalculateAge {
	
	
	public static int calculateage(LocalDate birthDate,LocalDate currentDate) {
	    // validate inputs ...
	    return Period.between(birthDate, currentDate).getYears();
	}

	

	
	
}


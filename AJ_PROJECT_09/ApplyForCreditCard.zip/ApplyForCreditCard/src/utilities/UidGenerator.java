package utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

public class UidGenerator {

	public static void main (String args []) {
		  Date date = new Date();  
SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
    String CURRENTDATE =  simpleDateFormat.format(date);
	System.out.println(CURRENTDATE);
	}
}